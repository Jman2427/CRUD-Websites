<?php

$host = "localhost";
$username = "jman2427";//#put user name here
$password = "JANGBRiCKS2427!";//#put password here
$dbname ="LEGO";//#put db name here

$set_id = $_POST["set_id"];
echo"$set_id";
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT * FROM Lego WHERE set_id='" . $_POST['set_id'] . "'";
//$result = mysql_query($query) or die($query."<br/><br/>".mysql_error());//Use this line to debug any database errors
$result = $conn->query($sql);
$set_name = $row[1];
$set_id = $row[2];
$Cost = $row[3];

echo nl2br("Here are the results for "." ". $_POST['set_id']);
echo "$set_id";
//$num_names = mysql_num_rows($roster_table);
if ($result->num_rows > 0)//will only do this if there is something to be returned from the aboe line
	{echo "<TABLE><TR><TD>set_name</TD><TD>set_id</TD><TD>cost</TD></TR>";
		// Iterate through all of the returned images, placing them in a table for easy viewing
	while($row = $result->fetch_assoc())
		{
			// The following few lines store information from specific cells in the data about an image
			echo "<TR>";
			//$domain = $_SERVER['SERVER_NAME'];
			echo "<TD>".$row['set_id']. "</TD><TD>". $row['set_name']. "</TD><TD>".$row['cost'] ."</TD>";
			echo "</TR>";
		}
	echo "</TABLE>";	
	}
	else{
		echo "<br> 0 results";
		}
?>