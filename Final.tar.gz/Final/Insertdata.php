<?php
//insertdata.php
if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {//Check it is coming from a form
    
		//mysql credentials
    $mysql_host = "localhost";
    $mysql_username = "jman2427";
    $mysql_password = "JANGBRiCKS2427!";
    $mysql_database = "LEGO";
	
	//delcare PHP variables
	
	$set_name = $_POST["set_name"];
	$set_id = $_POST["set_id"];
	$cost = $_POST["cost"];
	echo nl2br("The set "." ". $set_name . "has been added to our database . ", false);
    }

?>

*code below used to go under $cost but it didnt work and I gave up. Kept it here just in case tho*
	//Open a new connection to the MySQL server
	//see https://www.sanwebe.com/2013/03/basic-php-mysqli-usage for more info
	$mysqli = new mysqli($mysql_host, $mysql_username, $mysql_password, $mysql_database);
	
	//Output any connection error
	if ($mysqli->connect_error) {
		die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
	}   
	
		$statement = $mysqli->prepare("INSERT INTO LEGO (set_name, set_id, cost) VALUES(?, ?, ?)"); //prepare sql insert query
		var_dump($statement);
		//bind parameters for markers, where (s = string, i = integer, d = double,  b = blob)
		$statement->bind_param("sss", $set_name, $set_id, $cost);
		if($statement->execute())
			{
				//print output text
				echo nl2br("The set "." ". $set_name . " has been added to our database . ", false);
			}
			else{
					print $mysqli->error; //show mysql error if any 
				}

         }
else{
    echo ("error");
    }         
?>